@extends('layouts.app')
@section('content')
<div class="jumbotron text-center">
<h1> {{$title}}</h1>
<p>this is a password manager website</p>

@endsection