<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2> Viewing Passwords </h2>
        <div class="table-responsive">
            <table class="table">
                <tr class="info">
                    <th>Website</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Options</th>
                </tr>
               
            </div>
            <?php
                echo $id;
            ?>
        

           
        </table>
    </div>
</div>
<div class="row">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>