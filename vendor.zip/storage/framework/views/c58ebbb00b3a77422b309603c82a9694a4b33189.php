<?php $__env->startSection('content'); ?>
<?php 
                $key = $passes;
                function my_decrypt($data, $key) {
                //$key = $passes;
                // Remove the base64 encoding from our key
                $encryption_key = base64_decode($key);
                // To decrypt, split the encrypted data from our IV - our unique separator used was "::"
                list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
                return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
            } 
            $de = $post -> password;
            $depass = my_decrypt($de, $key);
                ?>
<h1> Edit Login</h1>
<?php echo Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST']); ?>

<div class="form-group">
            <?php echo e(Form::label('website', 'Website')); ?>

            <?php echo e(Form::text('website', $post->website, ['class' => 'form-control', 'placeholder' => 'http://'])); ?>

    </div>
    <div class="form-group">
            <?php echo e(Form::label('email', 'Email')); ?>

            <?php echo e(Form::text('email', $post->email, ['class' => 'form-control', 'placeholder' => ''])); ?>

    </div>
    <div class="form-group">
            <?php echo e(Form::label('password', 'Password')); ?>

            <?php echo e(Form::text('password', $depass, ['class' => 'form-control', 'placeholder' => ''])); ?>

    </div>
    <?php echo e(Form::hidden('_method', 'PUT')); ?>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>